int led1=11;
int led2=5;

void setup() {
   pinMode(led1, OUTPUT);
   pinMode(led2, OUTPUT);
}

void loop() {
    digitalWrite(led1, HIGH);
    digitalWrite(led2, LOW);
    _delay_ms(1000);
    digitalWrite(led1, LOW);
    digitalWrite(led2, HIGH);
    _delay_ms(1000); 
}

 

  