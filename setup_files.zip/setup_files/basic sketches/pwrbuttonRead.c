int pwr=10;
int i;

void setup() {
   pinMode(pwr, INPUT);
   Serial.begin(19200);
}

void loop() {
    i = digitalRead(pwr);
    fprintf(file_usb,"Power button status: %d\n",i); 
    _delay_ms(500);
}