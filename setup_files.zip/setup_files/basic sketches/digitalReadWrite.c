
int led1=11;

void setup() {
   pinMode(led1, OUTPUT);
   Serial.begin(19200);
}

void loop() {
	digitalWrite(led1, HIGH);
    int i;
    i = digitalRead(led1);
    fprintf(file_usb,"LED status: %d\n",i);
    _delay_ms(2000);
    digitalWrite(led1, LOW);
    i = digitalRead(led1);
    fprintf(file_usb,"LED status: %d\n",i);
    _delay_ms(2000);
}
