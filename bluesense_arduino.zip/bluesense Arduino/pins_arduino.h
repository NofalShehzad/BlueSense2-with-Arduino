#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

// ATMEL ATMEGA1284P (see bluesense schematic1)
//
//                   +---\/---+
//         (D 27) PB0  40|        |37  PA0 (AI 0 / D26)
//         (D 28) PB1  41|        |35  PA1 (AI 1 / D25)
//    INT2 (D 29) PB2  42|        |34  PA2 (AI 2 / D24)
//     PWM (D 30) PB3  43|        |33  PA3 (AI 3 / D23)
//  PWM/SS (D 31) PB4  44|        |36  PA4 (AI 4 / D22)
//      MOSI (D 0) PB5  1|        |32  PA5 (AI 5 / D21)
//  PWM/MISO (D 1) PB6  2|        |31  PA6 (AI 6 / D20)
//   PWM/SCK (D 2) PB7  3|        |30  PA7 (AI 7 / D19)
//                 RST  4|        |29  AREF
//                  VCC 5|        |28  GND 
//                 GND 18|        |27  AVCC
//                XTAL2 7|        |26  PC7 (D 18)
//                XTAL1 8|        |25  PC6 (D 17)
//       RX0 (D 3)  PD0 9|        |24  PC5 (D 16) TDI
//      TX0 (D 4)  PD1 10|        |23  PC4 (D 15) TDO
//  RX1/INT0 (D 5) PD2 11|        |22  PC3 (D 14) TMS
//  TX1/INT1 (D 6) PD3 12|        |21  PC2 (D 13) TCK
//       PWM (D 7) PD4 13|        |20  PC1 (D 12) SDA
//       PWM (D 8) PD5 14|        |19  PC0 (D 11) SCL
//       PWM (D 9) PD6 15|        |16  PD7 (D 10) PWM
//                   +--------+
//

/*
   PCINT15-8: D7-0  : bit 1
   PCINT31-24: D15-8  : bit 3
   PCINT23-16: D23-16 : bit 2
   PCINT7-0: D31-24   : bit 0
   */

#define NUM_DIGITAL_PINS            1
#define NUM_ANALOG_INPUTS           0
#define analogInputToDigitalPin(p)  ((p < NUM_ANALOG_INPUTS) ? (p) + 24 : -1)

#define digitalPinHasPWM(p)         ((p) == 3 || (p) == 4 || (p) == 6 || (p) == 7 || (p) == 12 || (p) == 13 || (p) == 14 || (p) == 15)

static const uint8_t SS   = 31;
static const uint8_t MOSI = 0;
static const uint8_t MISO = 1;
static const uint8_t SCK  = 2;

static const uint8_t SDA = 12;
static const uint8_t SCL = 11;
static const uint8_t LED = 2;

static const uint8_t A0 = 26;
static const uint8_t A1 = 25;
static const uint8_t A2 = 24;
static const uint8_t A3 = 23;
static const uint8_t A4 = 22;
static const uint8_t A5 = 21;
static const uint8_t A6 = 20;
static const uint8_t A7 = 19;

#define digitalPinToPCICR(p)    (((p) >= 0 && (p) < NUM_DIGITAL_PINS) ? (&PCICR) : ((uint8_t *)0))
#define digitalPinToPCICRbit(p) (((p) <= 7) ? 1 : (((p) <= 15) ? 3 : (((p) <= 23) ? 2 : 0)))
#define digitalPinToPCMSK(p)    (((p) <= 7) ? (&PCMSK2) : (((p) <= 13) ? (&PCMSK0) : (((p) <= 21) ? (&PCMSK1) : ((uint8_t *)0))))
#define digitalPinToPCMSKbit(p) ((p) % 8)

#ifdef ARDUINO_MAIN

#define PA 1
#define PB 2
#define PC 3
#define PD 4

// these arrays map port names (e.g. port B) to the
// appropriate addresses for various functions (e.g. reading
// and writing)
const uint16_t PROGMEM port_to_mode_PGM[] =
{
	NOT_A_PORT,
	(uint16_t) &DDRA,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
};

const uint16_t PROGMEM port_to_output_PGM[] =
{
	NOT_A_PORT,
	(uint16_t) &PORTA,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
};

const uint16_t PROGMEM port_to_input_PGM[] =
{
	NOT_A_PORT,
	(uint16_t) &PINA,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] =
{
	PA, // X_ADC0
	PA, // X_ADC1
	PA, // X_ADC2
	PA, // X_ADC3
	PA, // X_ADC7
	PB, // LED_1
	PB, // X_AIN0
	PB, // X_AIN1
	PC, // PWR_CHRG#
	PC, // LED_2
	PC, // PWR_PBSTAT
	PC, // LED_0 
	PD  // BLUE_Connect
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] =
{
	_BV(0), //PA 
	_BV(1),
	_BV(2),
	_BV(3),
	_BV(7),
	_BV(1), //PB
	_BV(2),
	_BV(3),
	_BV(2), //PC
	_BV(3),
	_BV(4),
	_BV(6),
	_BV(7)  //PD
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] =
{
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER
};

#endif // ARDUINO_MAIN

#endif // Pins_Arduino_h
// vim:ai:cin:sts=2 sw=2 ft=cpp
