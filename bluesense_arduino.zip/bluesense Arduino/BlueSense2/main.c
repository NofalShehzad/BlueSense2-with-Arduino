#include "cpu.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include <util/atomic.h>
#include <stdio.h>
#include <string.h>

#include "main.h"
#include "i2c.h"
#include "wait.h"
#include "init.h"
#include "dbg.h"
#include "system.h"

//#include "motionconfig.h"
#include "wait.h"
//#include "mode.h"

FILE *file_bt;			// Bluetooth
FILE *file_usb;			// USB
FILE *file_fb;			// Screen
FILE *file_dbg;			// Debug (assigned to file_bt or file_usb)
FILE *file_pri;			// Primary (assigned to file_bt or file_usb)

unsigned char sharedbuffer[520];










/******************************************************************************
	Timer interrupt vectors
******************************************************************************/
// CPU 1024Hz
ISR(TIMER1_COMPA_vect)
{
	_timer_tick_1024hz();
}




void init(void)
{
	init_basic();
}





/******************************************************************************
Main program loop
******************************************************************************/
int mainx(void)
{
	// Initialises the port IO, timers, interrupts and "printf" debug interface over I2C
	init_basic();
	
	// Initialise the rest of it
	//init_extended();
	
	
	int ledctr=0;
	while(1)
	{
		fprintf(file_usb,"Hello dan %d\n",ledctr);
		system_led_set(ledctr++);
		_delay_ms(500);
	}

	return 0;
}






   





