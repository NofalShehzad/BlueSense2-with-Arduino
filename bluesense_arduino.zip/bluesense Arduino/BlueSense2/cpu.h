#ifndef __CPU_H
#define __CPU_H

#ifdef __cplusplus
extern "C" {
#endif

#if HWVER==1
#define F_CPU 7372800UL
#endif
#if (HWVER==4) || (HWVER==5) || (HWVER==6) || (HWVER==7)
#define F_CPU 11059200UL
#endif


#ifdef __cplusplus
} // extern "C"
#endif




#endif